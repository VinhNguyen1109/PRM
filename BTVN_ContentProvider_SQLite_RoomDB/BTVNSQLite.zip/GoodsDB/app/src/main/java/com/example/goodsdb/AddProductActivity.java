package com.example.goodsdb;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import dao.AppDatabase;
import model.Product;

// AddProductActivity.java
public class AddProductActivity extends AppCompatActivity {
    EditText edtName, edtDescription, edtPrice;
    Button btnSave;
    AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        edtName = findViewById(R.id.edtName);
        edtDescription = findViewById(R.id.edtDescription);
        edtPrice = findViewById(R.id.edtPrice);
        btnSave = findViewById(R.id.btnSave);
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "goods.db").allowMainThreadQueries().build();

        btnSave.setOnClickListener(v -> {
            String name = edtName.getText().toString();
            String desc = edtDescription.getText().toString();
            String price =edtPrice.getText().toString();

            Product p = new Product(name, desc, price);
            db.productDao().insert(p);

            finish(); // quay về
        });
    }
}
