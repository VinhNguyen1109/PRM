package com.example.goodsdb;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import dao.AppDatabase;

public class MyContentProvider extends ContentProvider {

    public static final String AUTHORITY = "com.example.goodsdb.provider";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/product");

    private AppDatabase db;

    @Override
    public boolean onCreate() {
        db = AppDatabase.getInstance(getContext());
        return true;
    }

    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection,
                        @Nullable String selection, @Nullable String[] selectionArgs,
                        @Nullable String sortOrder) {
        Log.d("MY_PROVIDER", "query() called");
        Cursor cursor = db.productDao().getCursorAll();
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    // Các hàm khác nếu cần (insert, update, delete), ở đây không bắt buộc:
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
