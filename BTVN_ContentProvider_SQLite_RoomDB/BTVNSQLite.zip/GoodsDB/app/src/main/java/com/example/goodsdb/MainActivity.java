package com.example.goodsdb;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import adapter.ProductAdapter;
import dao.AppDatabase;
import model.Product;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private AppDatabase database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        FloatingActionButton btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddProductActivity.class);
            startActivity(intent);
        });
        Uri uri = Uri.parse("content://com.example.goodsdb.provider/product");

        Cursor cursor = getContentResolver().query(uri, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String price = cursor.getString(cursor.getColumnIndexOrThrow("price"));
                Log.d(TAG, name + " - " + price);
            }
            cursor.close();
        }
        database=AppDatabase.getInstance(this);
        recyclerView = findViewById(R.id.recyclerView);
        adapter = new ProductAdapter(new ProductAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Product product) {
                Intent intent = new Intent(MainActivity.this, UpdateProductActivity.class);
                intent.putExtra("product_id", product.getId());
                startActivity(intent);
            }

            @Override
            public void onEditClick(Product product) {
                Intent intent = new Intent(MainActivity.this, UpdateProductActivity.class);
                intent.putExtra("product_id", product.getId());
                startActivity(intent);
            }

            @Override
            public void onDeleteClick(Product product) {
                database.productDao().delete(product);
                List<Product> updatedList = database.productDao().getAllProducts();
                adapter.setProductList(updatedList);
            }
        });

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        if (database.productDao().getAllProducts().isEmpty()) {
            database.productDao().insert(new Product("Laptop", "Abc...", "20.000.000"));
            database.productDao().insert(new Product("Smartphone", "Xyz...", "15.000.00"));
            database.productDao().insert(new Product("Headphone", "Kzz...", "1000.000"));
        }

        List<Product> list = database.productDao().getAllProducts();
        adapter.setProductList(list);
    }
    @Override
    protected void onResume() {
        super.onResume();
        List<Product> list = database.productDao().getAllProducts();
        adapter.setProductList(list);
    }

}