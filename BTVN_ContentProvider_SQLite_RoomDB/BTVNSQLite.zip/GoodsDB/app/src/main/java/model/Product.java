package model;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(tableName = "product")
public class Product {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public String description;
    public String  price;
    public Product(String productName, String productDescription, String productPrice) {
        this.name = productName;
        this.description = productDescription;
        this.price = productPrice;
    }
}
