package com.example.goodsdb;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import model.Product;
import dao.AppDatabase;

public class UpdateProductActivity extends AppCompatActivity {

    private EditText edtName, edtDescription, edtPrice;
    private Button btnUpdate, btnDelete;
    private AppDatabase db;
    private Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);

        edtName = findViewById(R.id.edtName);
        edtDescription = findViewById(R.id.edtDescription);
        edtPrice = findViewById(R.id.edtPrice);
        btnUpdate = findViewById(R.id.btnUpdate);
        db = AppDatabase.getInstance(this);

        int productId = getIntent().getIntExtra("product_id", -1);
        if (productId == -1) {
            Toast.makeText(this, "Không tìm thấy sản phẩm", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        product = db.productDao().getProductById(productId);
        if (product != null) {
            edtName.setText(product.getName());
            edtDescription.setText(product.getDescription());
            edtPrice.setText(product.getPrice());
        }

        btnUpdate.setOnClickListener(v -> {
            product.setName(edtName.getText().toString());
            product.setDescription(edtDescription.getText().toString());
            product.setPrice(edtPrice.getText().toString()); // nếu bạn dùng kiểu String

            db.productDao().update(product);
            Toast.makeText(this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}