package com.example.btvn_recyclerview;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TabLayout tabLayout;

    List<Category> categoryList;
    CategoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        onBinding();
        onAction();
    }

    private void onBinding() {
        // Ánh xạ view
        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3)); // 3 cột

        // Khởi tạo danh sách category
        categoryList = new ArrayList<>();
        categoryList.add(new Category(R.drawable.pharmacy, "pharmacy"));
        categoryList.add(new Category(R.drawable.registry, "registry"));
        categoryList.add(new Category(R.drawable.cartwheel, "cartwheel"));
        categoryList.add(new Category(R.drawable.clothing, "clothing"));
        categoryList.add(new Category(R.drawable.shoes, "shoes"));
        categoryList.add(new Category(R.drawable.accessories, "accessories"));
        categoryList.add(new Category(R.drawable.baby, "baby"));
        categoryList.add(new Category(R.drawable.home, "home"));
        categoryList.add(new Category(R.drawable.patio_and_garden, "patio"));

        adapter = new CategoryAdapter(categoryList);

        // Mặc định ẩn RecyclerView và chưa set adapter
        recyclerView.setVisibility(View.INVISIBLE);
        recyclerView.setAdapter(null);
    }

    private void onAction() {
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();

                if (position == 2) { // Tab "CATEGORIES"
                    recyclerView.setVisibility(View.VISIBLE);
                    recyclerView.setAdapter(adapter);
                } else {
                    recyclerView.setAdapter(null);
                    recyclerView.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Có thể thêm xử lý nếu cần
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Có thể thêm xử lý nếu cần
            }
        });
    }
}
